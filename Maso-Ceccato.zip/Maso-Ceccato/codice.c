#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dipendencies/include/libpq-fe.h"

#define PG_HOST "127.0.0.1"
#define PG_USER "postgres"
#define PG_DB "progetto"
#define PG_PASS "postgres"
#define PG_PORT 5432

void checkResult(PGresult *res, const PGconn *conn) {
    if (PQresultStatus(res) != PGRES_TUPLES_OK) {
        printf("Errore: %s\n", PQerrorMessage(conn));
        PQclear(res);
        PQfinish((PGconn *)conn);
        exit(1);
    }
}

// funzione per stampare il risultato di ciascuna query
void stampaRisultati(PGresult *res) {
    int tuple = PQntuples(res);
    int campi = PQnfields(res);

    for (int i = 0; i < campi; i++) {
        printf("%-20s", PQfname(res, i));
    }
    printf("\n");

    for (int i = 0; i < tuple; i++) {
        for (int j = 0; j < campi; j++) {
            printf("%-20s", PQgetvalue(res, i, j));
        }
        printf("\n");
    }
}

int main() {
    char conninfo[250];
    sprintf(conninfo, "user=%s password=%s dbname=%s host=%s port=%d",
            PG_USER, PG_PASS, PG_DB, PG_HOST, PG_PORT);

    PGconn *conn = PQconnectdb(conninfo);

    if (PQstatus(conn) != CONNECTION_OK) {
        printf("Errore di connessione: %s\n", PQerrorMessage(conn));
        PQfinish(conn);
        return 1;
    }

    printf("Connessione avvenuta correttamente\n");

    int scelta;
    PGresult *res;

    while (1) {
        printf("\n--- SCEGLI QUERY ---\n");
        printf("1. Codice e numero di verifiche svolte da controllori a biglietti con costo maggiore di 50\n");
        printf("2. Nome e cognome degli utenti che hanno acquistato almeno 3 biglietti\n");
        printf("3. Codici dei treni che hanno percorso tratte che partono da (parametrizzata)\n");
        printf("4. Media del costo dei biglietti di tratte con distanze superiori ai 300km\n");
        printf("5. Numero di biglietti acquistati nelle varie giornate, con costo maggiore di (parametro) per tratte percorse da treni regionali\n");
        printf("6. Posti Businness classe1 classe2 disponibili in una tratta(parametro)\n");
        printf("7. Utenti ai quali è stato verificato un bigletto non valido su tratte composte da fermate(parametro)\n");
        printf("0. Esci\n");
        printf("Scegli una opzione (0-7): ");
        scanf("%d", &scelta);
        getchar(); // consuma newline

        if (scelta == 0) {
            printf("Esci.\n");
            break;
        }

        switch (scelta) {
            case 1:
                res = PQexec(conn, "SELECT V.cf_controllore, COUNT(*) as NumVerifiche FROM verifiche V, biglietto B WHERE V.id_biglietto = B.id AND B.costo > 50 GROUP BY V.cf_controllore");
                checkResult(res, conn);
                stampaRisultati(res);
                PQclear(res);
                break;

            case 2:
                res = PQexec(conn, "SELECT U.nome, U.cognome , count(*) as NumBiglietti FROM biglietto B, utente U WHERE B.codice_fiscale = U.codice_fiscale GROUP BY U.codice_fiscale HAVING COUNT(*) > 2");
                checkResult(res, conn);
                stampaRisultati(res);
                PQclear(res);
                break;

            case 3: {
                const char *query =
                "SELECT P.codice_treno FROM percorre P, tratta T WHERE P.tratta_id = T.id AND T.stazione_partenza = $1::varchar ";
                PQprepare(conn, "q_tratta_partenza", query, 1, NULL);

                char stazione_partenza[50];
                printf("Inserisci la stazione di partenza: ");
                fgets(stazione_partenza, sizeof(stazione_partenza), stdin);
                stazione_partenza[strcspn(stazione_partenza, "\n")] = 0;

                const char *param[1] = { stazione_partenza };
                res = PQexecPrepared(conn, "q_tratta_partenza", 1, param, NULL, NULL, 0);
                checkResult(res, conn);
                stampaRisultati(res);
                PQclear(res);
                break;
            }

            case 4:
                res = PQexec(conn, "SELECT avg(B.costo) AS MediaCosto FROM biglietto B, tratta T WHERE B.tratta_id = T.id AND T.distanza > 300");
                checkResult(res, conn);
                stampaRisultati(res);
                PQclear(res);
                break;

            case 5: {
                const char *query = "SELECT data_acquisto, COUNT(*) as NumBigliettiComprati FROM biglietto B, tratta T, percorre P, treno TR WHERE B.tratta_id = T.id AND T.id = P.tratta_id AND TR.codice = P.codice_treno AND TR.tipo = 'regionale' AND costo > $1::int GROUP BY data_acquisto";
                PQprepare(conn, "q_2", query, 1, NULL);

                int costo;
                printf("Inserisci il costo del biglietto: ");
                scanf("%d", &costo);
                getchar(); // consuma newline

                char costo_str[12];
                snprintf(costo_str, sizeof(costo_str), "%d", costo);

                const char *param[1] = { costo_str };
                res = PQexecPrepared(conn, "q_2", 1, param, NULL, NULL, 0);
                checkResult(res, conn);
                stampaRisultati(res);
                PQclear(res);
                break;
            }
            
            case 6: {
                const char *query =
                "WITH min_posti AS ( "
                "    SELECT p.tratta_id, "
                "           MIN(t.posti_classe1) AS min_classe1, "
                "           MIN(t.posti_classe2) AS min_classe2, "
                "           MIN(t.posti_business) AS min_business "
                "    FROM percorre p "
                "    JOIN treno t ON p.codice_treno = t.codice "
                "    WHERE p.tratta_id = $1::int "
                "    GROUP BY p.tratta_id "
                "), "
                "biglietti_contati AS ( "
                "    SELECT b.tratta_id, "
                "           COUNT(*) FILTER (WHERE tipo = 'prima classe' AND data_partenza = $2::date) AS prenotati_classe1, "
                "           COUNT(*) FILTER (WHERE tipo = 'seconda classe' AND data_partenza = $2::date) AS prenotati_classe2, "
                "           COUNT(*) FILTER (WHERE tipo = 'business' AND data_partenza = $2::date) AS prenotati_business "
                "    FROM biglietto b "
                "    WHERE b.tratta_id = $1::int "
                "    GROUP BY b.tratta_id "
                ") "
                "SELECT m.tratta_id, "
                "       (m.min_classe1 - COALESCE(b.prenotati_classe1, 0)) AS disponibili_classe1, "
                "       (m.min_classe2 - COALESCE(b.prenotati_classe2, 0)) AS disponibili_classe2, "
                "       (m.min_business - COALESCE(b.prenotati_business, 0)) AS disponibili_business "
                "FROM min_posti m "
                "LEFT JOIN biglietti_contati b ON m.tratta_id = b.tratta_id;";
                
                PQprepare(conn, "q_posti_disponibili", query, 2, NULL);
                
                int tratta_id;
                char data_partenza[20];
                
                printf("Inserisci l'ID della tratta: ");
                scanf("%d", &tratta_id);
                getchar(); // consuma newline
                
                printf("Inserisci la data di partenza (YYYY-MM-DD): ");
                fgets(data_partenza, sizeof(data_partenza), stdin);
                data_partenza[strcspn(data_partenza, "\n")] = 0;
                
                char tratta_str[12];
                snprintf(tratta_str, sizeof(tratta_str), "%d", tratta_id);
                
                const char *param[2] = { tratta_str, data_partenza };
                res = PQexecPrepared(conn, "q_posti_disponibili", 2, param, NULL, NULL, 0);
                checkResult(res, conn);
                stampaRisultati(res);
                PQclear(res);
                break;
            }
                
            case 7: {
                const char *query =
                    "SELECT u.nome, u.cognome, u.codice_fiscale "
                    "FROM utente u "
                    "JOIN biglietto b ON u.codice_fiscale = b.codice_fiscale "
                    "JOIN verifiche v ON v.id_biglietto = b.id "
                    "WHERE v.valido = FALSE "
                    "AND b.tratta_id IN ( "
                    "    SELECT f.tratta_id "
                    "    FROM fermata f "
                    "    WHERE f.stazione_nome = $1::varchar "
                    ");";

                PQprepare(conn, "q_utenti_non_validi", query, 1, NULL);

                char stazione[50];
                printf("Inserisci il nome della stazione: ");
                fgets(stazione, sizeof(stazione), stdin);
                stazione[strcspn(stazione, "\n")] = 0;

                const char *param[1] = { stazione };
                res = PQexecPrepared(conn, "q_utenti_non_validi", 1, param, NULL, NULL, 0);
                checkResult(res, conn);
                stampaRisultati(res);
                PQclear(res);
                break;
            }
            default:
                printf("Scelta non valida.\n");
                break;
        }
    }

    PQfinish(conn);
}
