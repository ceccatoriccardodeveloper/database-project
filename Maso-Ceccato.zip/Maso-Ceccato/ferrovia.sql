DROP TABLE IF EXISTS Verifiche;
DROP TABLE IF EXISTS Biglietto;
DROP TABLE IF EXISTS Utente;
DROP TABLE IF EXISTS Percorre;
DROP TABLE IF EXISTS Fermata;
DROP TABLE IF EXISTS Tratta;
DROP TABLE IF EXISTS Stazione;
DROP TABLE IF EXISTS Treno;

-- TABELLE
CREATE TABLE utente (
    codice_fiscale CHAR(16) PRIMARY KEY,
    nome VARCHAR(20) NOT NULL,
    cognome VARCHAR(20) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    tipo VARCHAR(20),
    CONSTRAINT validità_tipo CHECK (tipo IN('cliente','controllore')),
    CONSTRAINT check_validità_utente CHECK (codice_fiscale ~ '^[A-Z0-9]{16}$' AND email SIMILAR TO '%@%.%')
);

CREATE TABLE stazione (
    nome VARCHAR(30) PRIMARY KEY,
    città VARCHAR(20) NOT NULL,
    regione VARCHAR(20) NOT NULL
);

CREATE TABLE tratta (
    id SERIAL PRIMARY KEY,
    distanza INT NOT NULL,
    durata INTERVAL NOT NULL,
    stazione_partenza VARCHAR(30),
    binario_stazione_partenza INT NOT NULL,
    orario_stazione_partenza TIME NOT NULL,
    stazione_arrivo VARCHAR(30),
    binario_stazione_arrivo INT NOT NULL,
    orario_stazione_arrivo TIME NOT NULL,
    CONSTRAINT check_tratta_nulla CHECK (stazione_partenza IS DISTINCT FROM stazione_arrivo),
    FOREIGN KEY (stazione_partenza) REFERENCES stazione(nome) ON DELETE CASCADE,
    FOREIGN KEY (stazione_arrivo) REFERENCES stazione(nome) ON DELETE CASCADE
);

CREATE TABLE fermata (
    stazione_nome VARCHAR(30) NOT NULL,
    tratta_id INT NOT NULL,
    distanza_percorsa INT NOT NULL,
    posizione INT NOT NULL,
    binario INT NOT NULL,
    orario TIME NOT NULL,
    PRIMARY KEY (stazione_nome, tratta_id),
    FOREIGN KEY (stazione_nome) REFERENCES stazione(nome),
    FOREIGN KEY (tratta_id) REFERENCES tratta(id)
);

CREATE TABLE treno (
    codice VARCHAR(8) PRIMARY KEY,
    modello VARCHAR(40) NOT NULL,
    posti_classe1 INT NOT NULL,
    posti_classe2 INT NOT NULL,
    posti_business INT NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    CONSTRAINT validita_tipo CHECK (tipo IN ('regionale', 'alta velocità'))
);

CREATE TABLE percorre (
    tratta_id INT NOT NULL,
    codice_treno VARCHAR(8) NOT NULL,
    data_percorrenza DATE NOT NULL,
    orario_inizio TIME NOT NULL,
    durata INTERVAL NOT NULL,
    PRIMARY KEY (codice_treno, tratta_id),
    FOREIGN KEY (codice_treno) REFERENCES treno(codice),
    FOREIGN KEY (tratta_id) REFERENCES tratta(id)
);

CREATE TABLE biglietto (
    id SERIAL PRIMARY KEY,
    servizi BOOLEAN NOT NULL DEFAULT FALSE,
    tipo VARCHAR(20) NOT NULL,
    CONSTRAINT validita_tipo CHECK (tipo IN ('prima classe', 'seconda classe', 'business')),
    data_acquisto DATE NOT NULL,
    data_partenza DATE NOT NULL,
    costo INT NOT NULL,
    codice_fiscale CHAR(16) NOT NULL,
    tratta_id INT NOT NULL,
    FOREIGN KEY (tratta_id) REFERENCES tratta(id),
    FOREIGN KEY (codice_fiscale) REFERENCES utente(codice_fiscale)
);

CREATE TABLE verifiche (
    cf_controllore CHAR(16) NOT NULL,
    id_biglietto INTEGER NOT NULL,
    data_verifica TIMESTAMP NOT NULL,
    valido BOOLEAN NOT NULL,
    PRIMARY KEY (cf_controllore, id_biglietto),
    FOREIGN KEY (cf_controllore) REFERENCES utente(codice_fiscale),
    FOREIGN KEY (id_biglietto) REFERENCES biglietto(id)
);


-- STAZIONI
INSERT INTO stazione (nome, città, regione) VALUES
('Milano Centrale', 'Milano', 'Lombardia'),
('Roma Termini', 'Roma', 'Lazio'),
('Firenze SMN', 'Firenze', 'Toscana'),
('Bologna Centrale', 'Bologna', 'Emilia-Romagna'),
('Napoli Centrale', 'Napoli', 'Campania'),
('Torino Porta Nuova', 'Torino', 'Piemonte'),
('Venezia Mestre', 'Venezia', 'Veneto'),
('Verona Porta Nuova', 'Verona', 'Veneto'),
('Salerno', 'Salerno', 'Campania'),
('Genova Brignole', 'Genova', 'Liguria');

-- TRATTE 
INSERT INTO tratta (distanza, durata, 
	stazione_partenza, binario_stazione_partenza, orario_stazione_partenza,
    stazione_arrivo, binario_stazione_arrivo, orario_stazione_arrivo)
VALUES
(650, '3:30', 'Milano Centrale', 1, '08:00', 'Roma Termini', 3, '11:30'),
(250, '1:30', 'Roma Termini', 2, '12:00', 'Napoli Centrale', 4, '13:30'),
(300, '2:00', 'Firenze SMN', 2, '10:00', 'Verona Porta Nuova', 3, '12:00'),
(200, '1:20', 'Bologna Centrale', 5, '09:30', 'Venezia Mestre', 2, '10:50'),
(550, '3:10', 'Torino Porta Nuova', 1, '07:00', 'Salerno', 5, '10:10');

-- FERMATE
INSERT INTO fermata (stazione_nome, tratta_id, distanza_percorsa, posizione, binario, orario) VALUES
('Firenze SMN', 1, 200, 1, 3, '09:00'),
('Bologna Centrale', 1, 300, 2, 4, '09:40'),
('Napoli Centrale', 1, 600, 3, 5, '11:00'),

('Firenze SMN', 2, 50, 1, 2, '12:30'),
('Salerno', 2, 200, 2, 3, '13:15'),

('Verona Porta Nuova', 3, 100, 1, 1, '11:00'),
('Bologna Centrale', 3, 200, 2, 2, '11:30'),

('Verona Porta Nuova', 4, 100, 1, 1, '10:00'),

('Genova Brignole', 5, 300, 2, 1, '08:30');

-- TRENI
INSERT INTO treno VALUES
('TR100', 'Frecciarossa 1000', 100, 200, 50, 'alta velocità'),
('TR200', 'Italo EVO', 90, 180, 60, 'alta velocità'),
('TR300', 'Regionale Veloce', 80, 160, 30, 'regionale');

-- PERCORRENZE
INSERT INTO percorre VALUES
(1, 'TR100', '2025-05-10', '08:00', '3:30'),
(2, 'TR200', '2025-05-11', '12:00', '1:30'),
(3, 'TR300', '2025-05-12', '10:00', '2:00');

-- 100 UTENTI (90 clienti + 10 controllori)
DO $$
DECLARE
  i INT;
BEGIN
  FOR i IN 1..100 LOOP
    INSERT INTO utente(codice_fiscale, nome, cognome, email, tipo)
    VALUES (
      LPAD('CF' || i, 16, '0'),
      'Nome' || LPAD(i::TEXT, 3, '0'),
      'Cognome' || LPAD(i::TEXT, 3, '0'),
      'nome' || LPAD(i::TEXT, 3, '0') || '@mail.com',
      CASE WHEN i <= 90 THEN 'cliente' ELSE 'controllore' END
    );
  END LOOP;
END$$;

-- 300 BIGLIETTI (3 per ogni cliente)
DO $$
DECLARE
  i INT;
  codice CHAR(16);
  tratta_id INT;
BEGIN
  FOR i IN 1..90 LOOP
    codice := LPAD('CF' || i, 16, '0');
    FOR j IN 0..2 LOOP
      tratta_id := (j % 3) + 1;
      INSERT INTO biglietto(servizi, tipo, data_acquisto, data_partenza, costo, codice_fiscale, tratta_id)
      VALUES (
        CASE WHEN j = 2 THEN TRUE ELSE FALSE END,
        CASE 
          WHEN j = 0 THEN 'seconda classe'
          WHEN j = 1 THEN 'prima classe'
          ELSE 'business'
        END,
        DATE '2025-05-01' + (i % 5),
        DATE '2025-05-10' + (j % 3),
        20 + (i % 10) * 5 + j * 5,
        codice,
        tratta_id
      );
    END LOOP;
  END LOOP;
END$$;

-- 150 VERIFICHE su biglietti
DO $$
DECLARE
  controllore CHAR(16);
  biglietto_id INT;
  idx INT := 0;
BEGIN
  FOR biglietto_id IN SELECT id FROM biglietto ORDER BY id LOOP
    EXIT WHEN idx >= 150;
    SELECT codice_fiscale INTO controllore
    FROM utente
    WHERE tipo = 'controllore'
    ORDER BY codice_fiscale
    OFFSET FLOOR(RANDOM()*10)::INT
    LIMIT 1;
    INSERT INTO verifiche(cf_controllore, id_biglietto, data_verifica, valido)
    VALUES (
      controllore,
      biglietto_id,
      NOW() - (INTERVAL '1 day' * (idx % 5)),
      (idx % 10 <> 0)
    );
    idx := idx + 1;
  END LOOP;
END$$;


-- QUERY 1
SELECT V.cf_controllore, COUNT(*) as NumVerifiche 
FROM verifiche V, biglietto B 
WHERE V.id_biglietto = B.id AND B.costo > 50 GROUP BY V.cf_controllore

-- QUERY 2
SELECT U.nome, U.cognome , count(*) as NumBiglietti 
FROM biglietto B, utente U 
WHERE B.codice_fiscale = U.codice_fiscale 
GROUP BY U.codice_fiscale 
HAVING COUNT(*) > 2

-- INDICI PER OTTIMIZZAZIONE
CREATE INDEX idx_biglietto ON biglietto USING HASH (codice_fiscale);
CREATE INDEX idx_utente ON utente USING HASH (codice_fiscale);

-- QUERY 3
SELECT P.codice_treno 
FROM percorre P, tratta T 
WHERE P.tratta_id = T.id AND T.stazione_partenza = 'Milano Centrale'

-- QUERY 4
SELECT avg(B.costo) AS MediaCosto 
FROM biglietto B, tratta T 
WHERE B.tratta_id = T.id AND T.distanza > 300

-- QUERY 5
SELECT data_acquisto, COUNT(*) as NumBigliettiComprati 
FROM biglietto B, tratta T, percorre P, treno TR 
WHERE B.tratta_id = T.id AND T.id = P.tratta_id 
AND TR.codice = P.codice_treno AND TR.tipo = 'regionale' AND costo > 30 
GROUP BY data_acquisto